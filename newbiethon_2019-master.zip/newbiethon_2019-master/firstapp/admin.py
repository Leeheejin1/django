from django.contrib import admin
from .models import Blog, BlogData

admin.site.register(Blog)
admin.site.register(BlogData)

